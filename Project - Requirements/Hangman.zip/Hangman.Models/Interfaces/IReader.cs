﻿namespace Hangman.Models.Interfaces
{
    using System;

    /// <summary>
    /// 
    /// </summary>
    public interface IReader
    {
        string ReadCommand();
    }
}