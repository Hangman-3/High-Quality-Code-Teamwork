﻿namespace Hangman.Models
{
    using System;
    using System.Linq;
    using global::Hangman.Common.Interfaces;

    // 1. Document all members
    // 2. Ensure all methods are unit-testable
    // 3. Ensure property/members/methods validation
    //
    public class Word : IWord
    {
        // TODO: Fix IWord interface
        // TODO: string SecretWord (from Hangman.cs)
        // TODO: string OriginalWord (from Hangman.cs)
        // TODO: property validation
        // TODO: Override ToString() method
    }
}