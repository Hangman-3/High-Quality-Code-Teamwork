﻿namespace Hangman.Models
{
    using System;
    using System.Linq;

    public class Player
    {
        public string Name { get; set; }

        public int Points { get; set; }
    }
}