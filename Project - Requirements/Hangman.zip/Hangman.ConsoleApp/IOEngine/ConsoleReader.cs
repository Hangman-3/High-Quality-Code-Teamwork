﻿namespace Hangman.ConsoleApp.IOEngine
{
    using System;
    using global::Hangman.Data.Interfaces;

    public class ConsoleReader : IReader
    {
        public string ReadCommand()
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }
    }
}