﻿namespace Hangman.ConsoleApp.IOEngine
{
    using System;
    using global::Hangman.Data.Interfaces;

    public class ConsoleWriter : IWriter
    {
        public void ShowCommands()
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }

        public void ShowPlayground(char[,] playground)
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }

        public void ShowMessage(string message)
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }
    }
}