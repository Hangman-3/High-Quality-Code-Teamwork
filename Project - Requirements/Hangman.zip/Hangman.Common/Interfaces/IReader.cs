﻿namespace Hangman.Common.Interfaces
{
    using System;

    /// <summary>
    /// 
    /// </summary>
    public interface IReader
    {
        string ReadLine();
    }
}