namespace Hangman.Common.Interfaces
{
    public interface IWord
    {
    }
}