﻿namespace Hangman.Data.Interfaces
{
    using System;

    public interface IReader
    {
        string ReadCommand();
    }
}