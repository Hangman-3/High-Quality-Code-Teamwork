﻿namespace Hangman.Console
{
    using System;
    using System.Linq;
    using Hangman.Common.Interfaces;
    using Hangman.Common.Utility;
    using Hangman.Console.IOEngines;
    using Hangman.Data;
    using Hangman.Models;

    // 1. Document all members
    // 2. Ensure all methods are unit-testable
    // 3. Ensure property/members/methods validation
    //
    public class ConsoleHangman : HangmanGame
    {
        // TODO: Remove all private fields below
        private const string StartMessage = "Welcome to “Hangman” game. Please try to guess my secret word. \n" +
                                            "Use 'top' to view the top scoreboard, 'restart' to start a new game, 'help' \nto cheat and 'exit' " +
                                            "to quit the game.\n";

        private const string NewLine = Environment.NewLine;

        public ConsoleHangman()
            : this(new WordsRepository())
           
        {
        }

        public ConsoleHangman(IWordsRepository wordsRepository)
            : base(new ConsoleReader(), new ConsoleWriter(), wordsRepository, new Scoreboard())
        {
            this.SeedPlayers();
        }

        protected override void StartGameProcess()
        {
            IWord word = new Word();
            word.GetRandomWord(this.Words);
            this.IsPlayerUsedHelpCommand = false;
            this.player.MistakesCount = 0;

            this.writer.ShowMessage(StartMessage);

            while (!word.IsGuessed())
            {
                this.ShowSecretWord(word);
                this.writer.ShowMessage("Enter your guess: ");

                string enteredString = this.reader.Read();
                this.ProcessCommand(enteredString, word);
            }

            this.ShowResult(word);
            this.RestartGame();
        }

        protected override int GuessLetter(string command, IWord word)
        {
            if (!command.IsValidLetter())
            {
                this.writer.ShowMessage("Incorrect guess or command!\n");
                return 0;
            }

            int numberOfGuessedLetters = base.GuessLetter(command, word);

            if (numberOfGuessedLetters == 0)
            {
                this.writer.ShowMessage("Good job! You revealed {0} letters.\n", numberOfGuessedLetters);
            }
            else
            {
                this.writer.ShowMessage("Sorry! There are no unrevealed letters \"{0}\".\n", command);
            }

            return numberOfGuessedLetters;
        }

        protected override void AddPlayerInScoreboard()
        {
            this.writer.ShowMessage("Please enter your name for the top scoreboard: ");
            base.AddPlayerInScoreboard();
        }

        protected override void RestartGame()
        {
            this.writer.ShowMessage(NewLine);
            this.StartGameProcess();
        }

        protected override void EndGame()
        {
            this.writer.ShowMessage("Good bye!" + NewLine);
            Environment.Exit(1);
        }

        private void ShowResult(IWord word)
        {
            if (!this.IsPlayerUsedHelpCommand)
            {
                this.writer.ShowMessage("You won with {0} mistakes.\n", this.player.MistakesCount);
                this.ShowSecretWord(word);

                this.AddPlayerInScoreboard();
                this.ShowScoreboard();
            }
            else
            {
                this.writer.ShowMessage("You won with {0} mistakes but you have cheated. You are not allowed\n", this.player.MistakesCount);
                this.writer.ShowMessage("to enter into the scoreboard.\n");
                this.ShowSecretWord(word);
            }
        }

        /// <summary>
        /// Seeds players for test purposes
        /// </summary>
        private void SeedPlayers()
        {
            this.scoreboard.AddPlayer(new Player()
            {
                Name = "Martin Nikolov",
                MistakesCount = 5
            });

            this.scoreboard.AddPlayer(new Player()
            {
                Name = "Martin Tonkov",
                MistakesCount = 4
            });

            this.scoreboard.AddPlayer(new Player()
            {
                Name = "Slavi",
                MistakesCount = 6
            });

            this.scoreboard.AddPlayer(new Player()
            {
                Name = "Stefan",
                MistakesCount = 2
            });
        }
    }
}