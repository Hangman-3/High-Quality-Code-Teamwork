﻿namespace Hangman.WPF
{
    using System;
    using System.Linq;
    using System.Windows;
    using System.Windows.Controls;

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            this.InitializeComponent();
        }

        private void OnWindowLoaded(object sender, RoutedEventArgs e)
        {
            var wpfHangman = new WpfHangman();
            wpfHangman.Start();
        }
    }
}