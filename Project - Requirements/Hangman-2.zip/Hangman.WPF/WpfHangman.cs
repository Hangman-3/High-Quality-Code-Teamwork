﻿namespace Hangman.WPF
{
    using System;
    using System.Linq;
    using Hangman.Common.Interfaces;
    using Hangman.Common.Utility;
    using Hangman.Console.IOEngines;
    using Hangman.Data;
    using Hangman.Models;
    using Hangman.WPF.IOEngines;

    public class WpfHangman : HangmanGame
    {
        public WpfHangman()
            : this(new WordsRepository())
        {
        }

        public WpfHangman(IWordsRepository wordsRepository)
            : base(new WpfReader(null), new WpfWriter(null), wordsRepository, new Scoreboard())
        {
            this.SeedPlayers();
        }

        protected override void StartGameProcess()
        {
        }

        protected override int GuessLetter(string command, IWord word)
        {
            if (!command.IsValidLetter())
            {
                return 0;
            }

            int numberOfGuessedLetters = base.GuessLetter(command, word);
            return numberOfGuessedLetters;
        }

        protected override void AddPlayerInScoreboard()
        {
            this.writer.ShowMessage("Please enter your name for the top scoreboard: ");
            base.AddPlayerInScoreboard();
        }

        protected override void RestartGame()
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }

        protected override void EndGame()
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }

        /// <summary>
        /// Seeds players for test purposes
        /// </summary>
        private void SeedPlayers()
        {
            this.scoreboard.AddPlayer(new Player()
            {
                Name = "Martin Nikolov",
                MistakesCount = 5
            });

            this.scoreboard.AddPlayer(new Player()
            {
                Name = "Martin Tonkov",
                MistakesCount = 4
            });

            this.scoreboard.AddPlayer(new Player()
            {
                Name = "Slavi",
                MistakesCount = 6
            });

            this.scoreboard.AddPlayer(new Player()
            {
                Name = "Stefan",
                MistakesCount = 2
            });
        }
    }
}