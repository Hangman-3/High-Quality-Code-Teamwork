﻿namespace Hangman.Tests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class HangmanTests
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}