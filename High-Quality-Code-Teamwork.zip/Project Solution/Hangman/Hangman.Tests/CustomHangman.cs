namespace Hangman.Tests
{
    using System;
    using System.Linq;
    using Hangman.Common.Interfaces;
    using Hangman.Models;

    internal class CustomHangman : HangmanGame
    {
        public CustomHangman(IReader reader, IWriter writer, IWordsRepository wordsRepository, IScoreboard scoreboard)
            : base(reader, writer, wordsRepository, scoreboard)
        {
        }

        protected override void StartGameProcess()
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }

        protected override void RestartGame()
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }

        protected override void EndGame()
        {
            // TODO: Implement this method
            throw new NotImplementedException();
        }
    }
}